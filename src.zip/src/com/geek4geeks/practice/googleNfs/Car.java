package com.geek4geeks.practice.googleNfs;

public class Car {
	
	static final double handlingFactor = 0.8;
	private double topSpeed;
	private int accelaration;
	private int carIndex;
	private boolean hasNitroUsed;
	private double currentSpeed;
	
	public Car(final int carIndex) {
		this.carIndex = carIndex;
	}
	
	void updateSpeed() {
	
	}
	
	void useNitro() {
		
	}
	
	public int foo() {
		return 0;
	}

	public int foo1(int a) {
		return 0;
	}
}
